@extends('layouts.master')

@section('title')
  Smart Repair
@endsection
@section('content')
<div class="vertical-center text-center">
  <div class="container">
    <img src="storage/logo.png" class="img-responsive" style="max-width: 300px"></br>
    <p style="size:5em;">Smart Repair</p>

    <div class="container-fluid">
      <div class="col-md-12 text-center">
        @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
        <a  href="{{url('Merek')}}"><button class="btn btn-danger">Repair Now!</button></a>
      </div>
    </div>
  </div>
</div>
</div>
@endsection
