<?php $__env->startSection('title'); ?>
Smart Repair
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="vertical-center text-left">
  <div class="container">
    <h1 class="text-center">Tambah Alamat</h1>
    <?php echo Form::open(['action' => 'ProfileController@simpanAlamat']); ?>

      <div class="form-group">
        <?php echo e(form::label('nama_penerima','Nama Penerima')); ?>

        <?php echo e(form::text('nama_penerima','',['class'=>'form-control','placeholder'=>'Nama Penerima'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(form::label('nomor_hp','Nomor HP')); ?>

        <?php echo e(form::text('nomor_hp','',['class'=>'form-control','placeholder'=>'Nomor HP'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(form::label('alamat','Alamat Lengkap')); ?>

        <?php echo e(form::textarea('alamat','',['class'=>'form-control','placeholder'=>'Alamat Lengkap'])); ?>

      </div>
      <?php echo e(form::submit('Submit',['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>