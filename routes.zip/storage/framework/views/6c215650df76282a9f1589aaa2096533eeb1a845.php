<?php $__env->startSection('title'); ?>
Smart Repair
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="vertical-center text-center">
  <div class="container">
    <img src="storage/logo.png" class="img-responsive" style="max-width: 300px"></br>
    <p style="size:5em;">Smart Repair</p>

    <div class="container-fluid">
      <div class="col-md-12 text-center">
        <a  href="<?php echo e(url('Merek')); ?>"><button class="btn btn-danger">Repair Now!</button></a>
      </div>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>