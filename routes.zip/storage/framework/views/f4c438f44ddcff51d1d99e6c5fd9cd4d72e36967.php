<?php $__env->startSection('title'); ?>
Smart Repair
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="vertical-center text-center">
  <div class="container">
    <h2 class="page-header text-center" style="margin-top:20px;">Merek</h2>

    <?php $__currentLoopData = $merek->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merekchunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <?php $__currentLoopData = $merekchunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mereks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-4">
        <a class="block-link" href="/tipe/<?php echo e($mereks->id); ?>">
          <div class="card">
            <div class="thumbnail">
              <img src="<?php echo e($mereks->imagePath); ?>">
              <div class="caption">
                <h4><?php echo e($mereks->nama); ?></h4>
              </div>
            </div>
          </div>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($merek->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>