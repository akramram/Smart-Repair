<?php $__env->startSection('title'); ?>
Smart Repair
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="vertical-center">
  <div class="container">
    <h2 class="page-header text-center" style="margin-top:20px;">Masalah</h2>

    <table class="table table-hover">
      <thead>
      </thead>
      <tbody>
        <?php $__currentLoopData = $masalah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><a href="/Summary/<?php echo e($d->id); ?>"> <?php echo e($d->deskripsi); ?></a></td>
          <td><a href=""> <?php echo e($d->nama_komponen); ?></a></td>
          <td><a href="">Rp <?php echo e($d->harga); ?></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

        <?php echo e($masalah->render()); ?>

    <!--div class="container-fluid">
      <div class="col-md-12 text-center">
        <a  href="<?php echo e(url('Tipe')); ?>"><button class="btn btn-danger"><< Back</button></a>
        <a  href="<?php echo e(url('/')); ?>"><button class="btn btn-danger">Home</button></a>
        <a  href="<?php echo e(url('/Summary')); ?>"><button class="btn btn-danger">Next >></button></a>
      </div>
    </div-->
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>