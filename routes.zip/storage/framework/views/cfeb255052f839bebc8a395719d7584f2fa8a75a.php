<?php $__env->startSection('title'); ?>
Smart Repair
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="vertical-center text-center">
  <div class="container">
    <h2 class="page-header text-center" style="margin-top:20px;">Tipe</h2>


    <table class="table table-hover">
      <thead>
        <tr>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $mer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><a href="/Masalah/<?php echo e($d->id); ?>"> <?php echo e($d->nama); ?></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <?php echo e($mer->render()); ?>

    <!--div class="container-fluid">
      <div class="col-md-12 text-center">
        <a  href="<?php echo e(url('Merek')); ?>"><button class="btn btn-danger"><< Back</button></a>
        <a  href="<?php echo e(url('/')); ?>"><button class="btn btn-danger">Home</button></a>
        <a  href="<?php echo e(url('/Masalah')); ?>"><button class="btn btn-danger">Next >></button></a>
      </div>
    </div-->
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>