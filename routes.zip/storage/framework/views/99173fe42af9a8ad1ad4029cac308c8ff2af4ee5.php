<?php $__env->startSection('title'); ?>
  Smart Repair
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="vertical-center text-center">
  <div class="container">
    <img src="storage/logo.png" class="img-responsive" style="max-width: 300px"></br>
    <p style="size:5em;">Smart Repair</p>

    <div class="container-fluid">
      <div class="col-md-12 text-center">
        <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
        <a  href="<?php echo e(url('Merek')); ?>"><button class="btn btn-danger">Repair Now!</button></a>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>